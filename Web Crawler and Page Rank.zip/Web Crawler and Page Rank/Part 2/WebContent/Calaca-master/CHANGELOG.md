# Changelog

## 1.1.1 - Dec 9, 2014
- Add support for lucene queries
- Add support for specifying protocol
- Bug fix for port config

## 1.1.0 - Oct 19 2014
- Add pagination
- Add time taken and hits count for query
- Add bower.json
- Split js files

## 1.0.1 - Jul 24 2014
- Add documentation to show how to configure results. 
- Update the required configs/documentation
- Update css class names
- Add monitoring plug
- Add changelog

## 1.0.0 - Jun 15 2014
- Initial release
