package ir.a3.nasir;

public class PageData {
private String title;
private String text;
private String rawHtml;
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getText() {
	return text;
}
public void setText(String text) {
	this.text = text;
}
public String getRawHtml() {
	return rawHtml;
}
public void setRawHtml(String rawHtml) {
	this.rawHtml = rawHtml;
}

}
